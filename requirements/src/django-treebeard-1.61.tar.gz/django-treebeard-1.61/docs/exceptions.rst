Exceptions
==========

.. module:: treebeard.exceptions
.. moduleauthor:: Gustavo Picon <tabo@tabo.pe>
    
.. autoexception:: InvalidPosition

.. autoexception:: InvalidMoveToDescendant

.. autoexception:: PathOverflow

.. autoexception:: MissingNodeOrderBy
