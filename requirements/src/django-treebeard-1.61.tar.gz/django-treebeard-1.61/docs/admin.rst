Admin
=====

.. module:: treebeard.admin
.. moduleauthor:: aleh.fl
.. moduleauthor:: Gustavo Picon <tabo@tabo.pe>


.. autoclass:: TreeAdmin
   :show-inheritance:

   To be used by Django's admin.site.register
