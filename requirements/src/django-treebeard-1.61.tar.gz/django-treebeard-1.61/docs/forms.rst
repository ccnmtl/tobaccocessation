Forms
=====

.. module:: treebeard.forms
.. moduleauthor:: aleh.fl
.. moduleauthor:: Gustavo Picon <tabo@tabo.pe>

.. autoclass:: MoveNodeForm
   :show-inheritance:

    Read the `Django Form objects documentation`_ for reference.


    .. _`Django Form objects documentation`:
       http://docs.djangoproject.com/en/dev/topics/forms/#form-objects

