tinyMCE.addI18n('cy.template_dlg',{
title:"Templedi",
label:"Templedi",
desc_label:"Disgrifiad",
desc:"Mewnosod cynnwys templed rhagosodol",
select:"Dewis templed",
preview:"Rhagolygiad",
warning:"Rhybudd: Gall diweddaru templed gyda un arall achosi colled data.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Ionawr,Chwefror,Mawrth,Ebrill,Mai,Mehefin,Goffennaf,Awst,Medi,Hydref,Tachwedd,Rhagfyr",
months_short:"Ion,Chw,Maw,Ebr,Mai,Meh,Gor,Aws,Med,Hyd,Tac,Rha",
day_long:"Sul,Llun,Mawrth,Mercher,Iau,Gwener,Sadwrn,Sul",
day_short:"Sul,Llu,Maw,Mer,Iau,Gwe,Sad,Sul"
});