tinyMCE.addI18n('lb.paste_dlg',{
text_title:"Dr\u00E9ckt op \u00C4rer Tastatur Ctrl+V, fir den Text an ze f\u00FCgen.",
text_linebreaks:"Zeilen\u00EBmbr\u00EBch b\u00E4ibehalen",
word_title:"Dr\u00E9ckt op \u00C4rer Tastatur Ctrl+V, um den Text an ze f\u00FCgen."
});