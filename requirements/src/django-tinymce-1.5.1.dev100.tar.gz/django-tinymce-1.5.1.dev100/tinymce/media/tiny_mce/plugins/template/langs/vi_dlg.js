tinyMCE.addI18n('vi.template_dlg',{
title:"M\u1EABu",
label:"M\u1EABu",
desc_label:"M\u00F4 t\u1EA3",
desc:"Ch\u00E8n m\u1ED9t n\u1ED9i dung m\u1EABu \u0111\u1ECBnh ngh\u0129a tr\u01B0\u1EDBc",
select:"Ch\u1ECDn m\u1ED9t m\u1EABu",
preview:"Xem tr\u01B0\u1EDBc",
warning:"C\u1EA3nh b\u00E1o: C\u1EADp nh\u1EADt m\u1ED9t m\u1EABu v\u1EDBi m\u1ED9t s\u1EF1 sai kh\u00E1c c\u00F3 th\u1EC3 l\u00E0m m\u1EA5t d\u1EEF li\u1EC7u.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Th\u00E1ng M\u1ED9t,Th\u00E1ng Hai,Th\u00E1ng Ba,Th\u00E1ng T\u01B0,Th\u00E1ng N\u0103m,Th\u00E1ng S\u00E1u,Th\u00E1ng B\u1EA3y,Th\u00E1ng T\u00E1m,Th\u00E1ng Ch\u00EDn,Th\u00E1ng M\u01B0\u1EDDi,Th\u00E1ng M\u01B0\u1EDDi M\u1ED9t,Th\u00E1ng M\u01B0\u1EDDi Hai",
months_short:"Thg1,Thg2,Thg3,Thg4,Thg5,Thg6,Thg7,Thg8,Thg9,Th10,Th11,Th12",
day_long:"Ch\u1EE7 Nh\u1EADt,Th\u1EE9 Hai,Th\u1EE9 Ba,Th\u1EE9 T\u01B0,Th\u1EE9 N\u0103m,Th\u1EE9 S\u00E1u,Th\u1EE9 B\u1EA3y,Ch\u1EE7 Nh\u1EADt",
day_short:"CN,T2,T3,T4,T5,T6,T7,CN"
});