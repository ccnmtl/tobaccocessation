tinyMCE.addI18n('mk.template_dlg',{
title:"Predlo\u0161ci",
label:"Predlo\u017Eak",
desc_label:"Opis",
desc:"\u0412\u043C\u0435\u0442\u043D\u0438 sadr\u017Eaj predlo\u0161ka",
select:"Odaberite predlo\u017Eak",
preview:"Prikaz",
warning:"Upozorenje: Nadopuna predlo\u0161ka novim mo\u017Ee uzrokovati gubitak podataka.",
mdate_format:"%d.%m.%Y %H:%M:%S",
cdate_format:"%d.%m.%Y %H:%M:%S",
months_long:"januar,februar,mart,april,maj,juni,juli,avgust,septembar,oktobar,novembar,decembar",
months_short:"jan,feb,mar,apr,maj,jun,jul,avg,sep,okt,nov,dec",
day_long:"nedelja,ponedeljak,utorak,sreda,\u010Detvrtak,petak,subota,nedelja",
day_short:"ned,pon,uto,sri,\u010Det,pet,sub,ned"
});