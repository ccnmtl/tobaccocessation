tinyMCE.addI18n('ro.template_dlg',{
title:"\u015Eabloane",
label:"\u015Eablon",
desc_label:"Descriere",
desc:"Insereaz\u0103 \u015Fablon",
select:"Selecteaz\u0103 \u015Fablon",
preview:"Previzualizare",
warning:"Aten\u0163ie: Schimbarea \u015Fablonului poate provoca pierderi de date",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Ianuarie,Februarie,Martie,Aprilie,Mai,Iunie,Iulie,August,Septembrie,Octombrie,Noiembrie,Decembrie",
months_short:"Ian,Feb,Mar,Apr,Mai,Iun,Iul,Aug,Sep,Oct,Noi,Dec",
day_long:"Duminic\u0103,Luni,Mar\u0163i,Miercuri,Joi,Vineri,S\u00E2mb\u0103t\u0103,Duminic\u0103",
day_short:"Dum,Lun,Mar,Mie,Joi,Vin,S\u00E2m,Dum"
});