tinyMCE.addI18n('cs.template_dlg',{
title:"\u0160ablony",
label:"\u0160ablona",
desc_label:"Popis",
desc:"Vlo\u017Eit p\u0159eddefinovan\u00FD obsah ze \u0161ablony",
select:"Vybrat \u0161ablonu",
preview:"N\u00E1hled",
warning:"Upozorn\u011Bn\u00ED: Aktualizace \u0161ablony jinou zp\u016Fsob\u00ED ztr\u00E1tu dat.",
mdate_format:"%d.%m.%Y %H:%M:%S",
cdate_format:"%d.%m.%Y %H:%M:%S",
months_long:"Leden,\u00DAnor,B\u0159ezen,Duben,Kv\u011Bten,\u010Cerven,\u010Cervenec,Srpen,Z\u00E1\u0159\u00ED,\u0158\u00EDjen,Listopad,Prosinec",
months_short:"Led,\u00DAno,B\u0159e,Dub,Kv\u011B,\u010Cer,\u010Cvc,Srp,Z\u00E1\u0159,\u0158\u00EDj,Lis,Pro",
day_long:"Ned\u011Ble,Pond\u011Bl\u00ED,\u00DAter\u00FD,St\u0159eda,\u010Ctvrtek,P\u00E1tek,Sobota,Ned\u011Ble",
day_short:"Ne,Po,\u00DAt,St,\u010Ct,P\u00E1,So,Ne"
});