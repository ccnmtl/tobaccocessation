tinyMCE.addI18n('id.template_dlg',{
title:"Templates",
label:"Template",
desc_label:"Description",
desc:"Menyisipkan template standar isi",
select:"Select a template",
preview:"Preview",
warning:"Warning: mengupdate template yang berbeda dapat menyebabkan kehilangan data",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Januari,Februari,Maren,April,Mei,Juni,Juli,Agustus,September,Oktober,November,Desember",
months_short:"Jan,Feb,Mar,Apr,Mei,Jun,Jul,Ags,Sep,Okt,Nov,Des",
day_long:"Minggu,Senin,Selasa,Rabu,Kamis,Jumat,Sabtu,Minggu",
day_short:"Min,Sen,Sel,Rab,Kam,Jum,Sab,Min"
});