tinyMCE.addI18n('ca.template_dlg',{
title:"Plantilles",
label:"Plantilla",
desc_label:"Descripci\u00F3",
desc:"Insereix el contingut de plantilla predefinit",
select:"Seleccioneu una plantilla",
preview:"Previsualitzaci\u00F3",
warning:"Av\u00EDs: Actualitzar una plantilla amb una altra diferent pot provocar p\u00E8rdua d\'informaci\u00F3.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"gener,febrer,mar\u00E7,abril,maig,juny,juliol,agost,setembre,octubre,novembre,desembre",
months_short:"gen.,febr.,mar\u00E7,abr.,maig,juny,jul.,ag.,set.,oct.,nov.,des.",
day_long:"diumenge,dilluns,dimarts,dimecres,dijous,divendres,dissabte,diumenge",
day_short:"dg.,dl.,dt.,dc.,dj.,dv.,ds.,dg."
});